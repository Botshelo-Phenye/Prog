/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicare_hospital;

import com.mycompany.medicare_hospital.PatientCategory;

/**
 *
 * @author phenb
 */
public class Inpatient extends Patient {
    private String wardNumber; //Ward assign
    private String bedNumber;  //Bed assign

    // Constructor initializes both base and extra attributes
    public Inpatient(String id, String firstName, String lastName, int age,
                     String gender, String condition, String wardNumber, String bedNumber) {
        super(id, firstName, lastName, age, gender, condition, PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    
    
    @Override
    public void displayDetails() {
        System.out.println(toString());
    }

    // Override toString and displaydetails to add ward/bed info
   
    @Override
    public String toString() {
        return super.toString() + " | Ward: " + wardNumber + " | Bed: " + bedNumber;
    }
}