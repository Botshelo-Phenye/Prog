/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicare_hospital;

/**
 *
 * @author phenb
 */
public class Reports {
private PatientManagement pm;
private Bedmanagement bm;
    public Reports(PatientManagement pm, Bedmanagement bm) {
        this.pm=pm;
        this.bm=bm;
              
    }
    public void generateReports(){
    System.out.println("\n=== Hospital Reports ===");
        System.out.println("Total Registered Patients: " + pm.getTotalPatients());
        System.out.println("Total Occupied Beds: " + bm.countOccupiedBeds());
        System.out.println("Ward Occupancy: " + 
            (bm.countOccupiedBeds() * 100 / 20) + "%");
        System.out.println("\nAll Patients:");
        pm.displayPatients();
        System.out.println("\nAvailable Beds:");
        bm.displayAvailableBeds();
        System.out.println("\nOccupied Beds:");
        bm.displayOccupiedBeds();    
    }
}
