/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicare_hospital;

/**
 *
 * @author phenb
 */
public class Bedmanagement {
    private String[] beds = new String[20]; // created an array that can hold 20 beds
    
    public Bedmanagement(){
        for (int i =0; i<beds.length;i++){
            beds[i]="Available";
        } 
    }
//bed Allocation
    public boolean allocateBed(String patientID){
        for (int i =0;i < beds.length;i++){
            if (beds[i].equals("Available")){
                beds[i]=patientID;
                System.out.println("Bed B"+(i+1)+"allocated to patient "+patientID);
                return true;
            }
        }
        System.out.println("Patient not found in any bed. ");
        return false;
    }     
    // Display ward layout (4x5)
    public void displayWardLayout() {
        for (int i = 0; i < beds.length; i++) {
            System.out.print("B" + (i+1) + ": " + beds[i] + "\t");
            if ((i+1) % 5 == 0) System.out.println();
        }
    }

    // Display available beds
    public void displayAvailableBeds() {
        System.out.println("Available Beds:");
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].equals("Available")) {
                System.out.println("B" + (i+1));
            }
        }
    }
    // Display occupied beds
    public void displayOccupiedBeds() {
        System.out.println("Occupied Beds:");
        for (int i = 0; i < beds.length; i++) {
            if (!beds[i].equals("Available")) {
                System.out.println("B" + (i+1) + " -> Patient " + beds[i]);
            }
        }
    }

    // Count occupied beds
    public int countOccupiedBeds() {
        int count = 0;
        for (String bed : beds) {
            if (!bed.equals("Available")) count++;
        }
        return count;
    }
    // Release bed when patient is discharged
    public boolean releaseBed(String patientId) {
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].equals(patientId)) {
                beds[i] = "Available";
                System.out.println("Bed B" + (i+1) + " released.");
                return true;
            }
        }
        System.out.println("Patient not found in any bed.");
        return false;
    }
    
}
