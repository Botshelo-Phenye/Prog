/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicare_hospital;
import java.util.ArrayList;

/**
 *
 * @author phenb
 */
class PatientManagement {
   ArrayList<Patient> patients = new ArrayList<>();
   public void registerPatient(Patient patient){
    patients.add(patient);
       System.out.println("Patient Registered successfully");
       
   }
   public Patient search(String patientID){
    for (Patient p :patients){
        if (p.getpatientID().equalsIgnoreCase(patientID)){
         return p;   
        }
    } 
    return null;
   } 
   public void updatePatient(String patientID, String newCondition, PatientCategory newCategory){
       Patient p = search(patientID);
       if (p!=null){
           p.setmedical(newCondition);
           p.setcategory( newCategory);
           System.out.println("Patient updated successfully");
       }else{System.out.println("Patient not found");}
       
   }
   public void delete(String patientID){
    Patient p = search(patientID);
    if (p != null){
      patients.remove(p);
        System.out.println("Patient Deleted");
    }else{System.out.println("Patient not Deleted");}
   }
   public void displayPatients(){
       for (Patient p : patients){
           System.out.println(p);
       }
   }
   public int getTotalPatients(){
       return patients.size();
   }

   
}

    
