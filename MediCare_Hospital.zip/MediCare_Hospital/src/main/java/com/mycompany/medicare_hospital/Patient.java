/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicare_hospital;

//import com.mycompany.medicare_hospital.MediCare_Hospital.PatientCategory;

/**
 *
 * @author phenb
 */
public class Patient {
    
         protected String patientID;
         protected String firstName;
         protected String lastName;
         protected String gender;
         protected String medicalCondition;
         protected PatientCategory category;//enum type
         protected int age;
        
        
        public Patient(String id, String firstName, String lastName, int age, String gender 
                , String condition, PatientCategory category){
       this.patientID=id;
       this.firstName=firstName;
       this.lastName=lastName;
       this.gender=gender;
       this.medicalCondition=condition;
       this.category=category;
       this.age=age;
   }

   

  
        public String getpatientID(){return patientID;}
        public String getfirstName(){return firstName;}
        public String getlastName(){return lastName;}
        public String getGender(){return gender;}
        public int getAge(){return age;}
        public String getmedicalCondition(){return medicalCondition;}
        public PatientCategory getcategory(){return category;}
 
        public void setmedical(String medicalCondition ){
            this.medicalCondition=medicalCondition;
        }
        public void setcategory(PatientCategory category){
           this.category=category;
        }
        public void displayDetails(){
            System.out.println(toString());
        }
       
       public String toString(){
           return patientID +"|"+firstName+" "+lastName+"|Age: "+
       age+"|Gender: "+gender+" | Condition: "+ medicalCondition+
       " | Category: "+ category;            } 

   
        
    }
    
    

